import { Route, RouterProvider, Routes, createBrowserRouter } from "react-router-dom"
import Nav from "./components/layouts/Nav"
import Signin from "./components/pages/Signin"
import Signup from "./components/pages/Signup"
import Dashboard from "./components/pages/Dashboard"
import Update from "./components/pages/Update"
import CreateProduct from "./components/pages/CreateProduct"
import ProductDetails from "./components/pages/ProductDetails"
import { Toaster } from "react-hot-toast"
import AuthRouter from "./components/utils/AuthRouter"
import Home from "./components/pages/Home"
import Root from "./components/layouts/Root"


function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Root />,
      children: [
    
        {
          path: "/",
          element: <Home/>,
        },
        {
          path: "/signup",
          element: <Signup/>,
        },
        {
          path: "/login",
          element: <Signin />,
        },
        {
          path: "/*",
          element: <Signin />,
        },
        
  
        {
          element : <AuthRouter />,
          children: [
           
            {
              path: "/create",
              element: <CreateProduct />,
            },
            {
              path: "/dashboard",
              element: <Dashboard />,
            },
            {
              path: "/update/:id", 
              element: <Update/>,
            },
            {
              path: "/view/:id", 
              element: <ProductDetails/>,
            },
          ],
        },
      ],
      }
      ],
    
  );


  return (
    <>
    <Toaster/>
      {/* <Nav/> */}
      {/* <Routes>
        <Route path="/" element={<Signup/>}/>
        <Route path="/login" element={<Signin/>}
        
      />
        <Route path="/dashboard" element={<Dashboard/>}/>
        <Route path="/create" element={<CreateProduct/>}/>
        <Route path="/update/:id" element={<Update/>}/>
        <Route path="/view/:id" element={<ProductDetails/>}/>
      </Routes> */}
<RouterProvider router={router} />
    </>
  )
}


export default App
