import React from 'react'
import Nav from '../layouts/Nav'
import { useSelector } from 'react-redux'
import Signin from './Signin'
import CreateProduct from './CreateProduct'

const Home = () => {
    const { isLoggedIn } = useSelector((state) => state.auth)
  return (
    <>
      {!isLoggedIn ? (
        <Signin />
      ) : (
        <>
          <CreateProduct />
        </>
      )}
    </>
  )
}

export default Home