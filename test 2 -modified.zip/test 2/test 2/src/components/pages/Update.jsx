import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getProductById, updateItem } from "../services/helper";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";

const Update = () => {
  const navigate = useNavigate();

  const { id } = useParams();
  const queryClient = useQueryClient();

  const { isLoading, isPending, isError, data, error } = useQuery({
    queryKey: ["productList", id],
    queryFn: () => getProductById(id),
  });
  console.log(data?.data);
  const [image, setImage] = useState(null);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm();
  useEffect(() => {
    setImage(data?.data?.image);
    setValue("name", data?.data?.name);
    setValue("price", data?.data?.price);
    setValue("description", data?.data?.description);
    setValue("brand", data?.data?.brand);
  }, [data]);

  const { mutate } = useMutation({
    mutationFn: updateItem,
    onSuccess: () => {
        toast.success('Item will updated')
      queryClient.invalidateQueries(["productList"]);
      navigate("/dashboard");
    },
  });
  if (isLoading) return "loading...";
  if (isError) return `Error: ${error.message}`;

  const submitHandler = (data) => {
    const fd = new FormData();
    fd.append("name", data?.name);
    fd.append("price", data?.price);
    fd.append("description", data?.description);
    fd.append("brand", data?.brand);

    fd.append("image", image);
    mutate({ id, fd });
  };

  return (
    <div className="d-flex align-items-center justify-content-evenly ">
     
       
      <form className="m-5 p-5" onSubmit={handleSubmit(submitHandler)}>
      <h1>Update</h1>
        <div className="row mb-3">
          
          <div className="col-sm-10">
            <input
              type="text"
              placeholder="Name"
              className="form-control"
              id="inputEmail3"
              {...register("name", { required: true })}
            />
          </div>
        </div>
        <div className="row mb-3">
          
          <div className="col-sm-10">
            <input
              type="number"
              placeholder="Price"
              className="form-control"
              id="inputEmail4"
              {...register("price", { required: true })}
            />
          </div>
        </div>
        <div className="row mb-3">
          
          <div className="col-sm-10">
            <input
              type="text"
              placeholder="Description"
              className="form-control"
              id="inputEmail5"
              {...register("description", { required: true })}
            />
          </div>
        </div>
        <div className="row mb-3">
          
          <div className="col-sm-10">
            <input
              type="text"
              placeholder="Brand"
              className="form-control"
              id="inputEmail6"
              {...register("brand", { required: true })}
            />
          </div>
        </div>

        <div className="input-group mb-3">
          
          <input
            type="file"
            className="form-control"
            id="inputGroupFile02"
            onChange={(e) => setImage(e.target.files[0])}
          />
        </div>

        <div className="d-flex flex wrap gap-5">
          <button type="submit" className="btn btn-primary">
            Update Item
          </button>
          
        </div>
        <div>
        <button
            onClick={() => navigate("/dashboard")}
            className="btn btn-dark"
          >
            Go to dashBoard
          </button>
        </div>
      </form>
    </div>
  );
};

export default Update;
