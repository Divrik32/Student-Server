import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { logIn } from '../redux/features/authSlice';
import { login } from '../services/helper';
import Nav from '../layouts/Nav';


const Signin = () => {
  localStorage.clear();

    const {
        register,
        handleSubmit,
        watch,
        formState: { errors },
      } = useForm();
      const dispatch = useDispatch();
      const navigate = useNavigate();
      const [isLoading, setIsLoading] = useState(false); // Loading state

      
    
      const submithandler = async (data) => {
        setIsLoading(true); // Set loading state to true
        const res = await login(data);
        console.log(res);

        if (res?.status) {
          dispatch(logIn(res));
          navigate("/dashboard");
        }
        setIsLoading(false); // Reset loading state after action completes

      };
  return (
    <div>
      {/* <Nav/> */}
    <div className="m-2 d-flex align-items-center justify-content-evenly">
    
    <form className="m-5 p-5"  onSubmit={handleSubmit(submithandler)}>
    <h1> Login Now</h1>
      <div className="mb-3">
        
        <input
          type="email"
          placeholder="Email ID"
          className="form-control"
          id="exampleInputEmail1"
          aria-describedby="emailHelp"
          {...register("email", { required: true })}
        />
        
      </div>
      <div className="mb-3">
        
        <input
          type="password"
          placeholder="Password"
          className="form-control"
          id="exampleInputPassword1"
          {...register("password", { required: true })}
        />
      </div>
      
      <button type="submit" disabled={isLoading} className="btn btn-primary">
      {isLoading ? 'Loading...' : 'Login'}
      </button>
    </form>
  </div>
  </div>
  )
}

export default Signin