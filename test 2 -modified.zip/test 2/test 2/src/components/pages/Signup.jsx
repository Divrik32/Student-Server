import { useMutation, useQueryClient } from "@tanstack/react-query";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { signup } from "../services/helper";
import Nav from "../layouts/Nav";
import '../pages/style.css'
import { ToastContainer, toast } from 'react-toastify';


const Signup = () => {
    const {
        register,
        handleSubmit,
        watch,
        formState: { errors },
      } = useForm();
    
      const navigate = useNavigate();
      const queryClient = useQueryClient();
      const [image, setImage] = useState(null);
    
      const { mutate } = useMutation({
        mutationFn: signup,
        onSuccess: (data) => {
          console.log(data);
          toast.success(data?.message)
          //   queryClient.invalidateQueries({ queryKey: ['userList'] })
          queryClient.invalidateQueries(["productList"]);
        },
      });
    
      const submitHandler = async (data) => {
        const fd = new FormData();
        fd.append("name", data?.name);
        fd.append("email", data?.email);
        fd.append("mobile", data?.mobile);
        fd.append("password", data?.password);
        fd.append("first_school", data?.first_school);
        fd.append("image", image);
        console.log(fd);
    
        mutate(fd);
        toast.success(data?.message)
        navigate("/login");
      };
      return (
        <div> 
          {/* <Nav/> */}
          <div className="d-flex align-items-center justify-content-evenly ">
        
            
            <form className="m-5 p-5" onSubmit={handleSubmit(submitHandler)}>
            <h1>Register Now</h1>

              <div className="row mb-3">
                
                <div className="col-sm-10">
                  <input
                    type="text"
                    placeholder="Name"
                    className="form-control"
                    id="inputEmail3"
                    {...register("name", { required: true })}
                  />
                </div>
              </div>
              <div className="row mb-3">
                
                <div className="col-sm-10">
                  <input
                    type="email"
                    placeholder="Email ID"
                    className="form-control"
                    id="inputEmail4"
                    {...register("email", { required: true })}
                  />
                </div>
              </div>
              <div className="row mb-3">
                
                <div className="col-sm-10">
                  <input
                    type="Mobile"
                    placeholder="Mobile no."
                    className="form-control"
                    id="inputEmail5"
                    {...register("mobile", { required: true })}
                  />
                </div>
              </div>
              <div className="row mb-3">
              
                <div className="col-sm-10">
                  <input
                    type="password"
                    placeholder="Password"
                    className="form-control"
                    id="inputEmail6"
                    {...register("password", { required: true })}
                  />
                </div>
              </div>
              <div className="row mb-3">
                
                <div className="col-sm-10">
                  <input
                    type="text"
                    placeholder="First School"
                    className="form-control"
                    id="inputEmail7"
                    {...register("first_school", { required: true })}
                  />
                </div>
              </div>
    
              <div className="input-group mb-3">
                
                <input
                  type="file"
                  className="form-control"
                  id="inputGroupFile02"
                  onChange={(e) => setImage(e.target.files[0])}
                />
              </div>
    
              <button type="submit" className="btn btn-primary">
                Sign Up
              </button>
            </form>
          </div>
        </div>
      );
    };

export default Signup;
