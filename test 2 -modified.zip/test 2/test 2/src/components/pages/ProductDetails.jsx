import { useQuery, useQueryClient } from "@tanstack/react-query";
import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getProductById } from "../services/helper";

const ProductDetails = () => {
  const navigate = useNavigate();

  const { id } = useParams();
  const queryClient = useQueryClient();

  const { isLoading, isPending, isError, data, error } = useQuery({
    queryKey: ["productList", id],
    queryFn: () => getProductById(id),
  });
  console.log(data);
  return (
    <div className="pro-details" >
            <h1 className="product-head">Product Details</h1>

      <div className="card mb-3" style={{ maxWidth: 540 }}>
        <div className="row g-0">
          <div className="col-md-4">
            <img
              src={data?.data?.image}
              className="img-fluid rounded-start"
              alt="..."
            />
          </div>
          <div className="col-md-8">
            <div className="card-body">
              <h4 className="card-title">{data?.data?.name}</h4>
              <br />
              <h6 className="card-text"> Brand : {data?.data?.brand}</h6>

              <p className="list-group-item">Description : {data?.data?.description}</p>
              <h6 className="list-group-item">Price: Rs.{data?.data?.price}</h6>
              <br />
              <br />

              
            </div>
           
          </div>
          <div className="pro-btn">
            <button
                onClick={() => navigate("/dashboard")}
                className="btn btn-dark"
              >
                Go to dashBoard
              </button>
            </div>
        </div>
        
      </div>
    </div>
  );
};

export default ProductDetails;
