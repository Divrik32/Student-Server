import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import React from "react";
import { deleteItem, getItem } from "../services/helper";
import { Link } from "react-router-dom";
import Nav from "../layouts/Nav";

const Dashboard = () => {
  const queryClient = useQueryClient();
  
  const { data, error, isLoading, isFetching } = useQuery({
    queryKey: ["items"],
    queryFn: getItem,
  });
  const { mutate } = useMutation({
    mutationFn: deleteItem,
    onSuccess: () => {
      console.log("Delete successfully");
      queryClient.invalidateQueries({ queryKey: ["items"] });
    },
  });

  if (isFetching) return <div>Fetching...</div>;
  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div>
      {/* <Nav/> */}
    <div className="d-flex flex-column align-items-center">
      <div>
        <h1 className="product-headline">Products List</h1>
      </div>

      <div>
        <div className="d-flex flex-wrap gap-2 justify-item-evenly">
          {data?.data?.map((item) => {
            return (
              <div key={item._id}>
                
                <div className="card" style={{ width: "18rem" }}>
                  <img
                    src={item?.image}
                    className="card-img-top"
                    alt="..."
                    height={200}
                    width={265}
                  />
                  <div className="card-body">
                    <h6 className="card-title">Name: {item.name}</h6>
                    <p className="card-text">Brand: {item.brand}</p>
                  </div>
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item">Discription: {item.description}</li>
                    <h6 className="list-group-item">Price: Rs.{item.price}</h6>
                  </ul>
                  <div className="card-body d-flex flex wrap gap-1">
                    <Link className="btn btn-dark" to={`/view/${item._id}`} ><i class="fa fa-eye" aria-hidden="true"/></Link>
                    <button
                      className="btn btn-danger"
                      onClick={() => mutate(item._id)}
                    ><i class="fa fa-trash" aria-hidden="true"/>
                      
                    </button>
                    <Link
                      className="btn btn-primary"
                      to={`/update/${item._id}`}
                    ><i class="fa fa-pencil" aria-hidden="true"/>
                      
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
    </div>
  );
};

export default Dashboard;
