import { useMutation, useQueryClient } from "@tanstack/react-query";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { createItem } from "../services/helper";
import Nav from "../layouts/Nav";
import { useSelector } from "react-redux";


  const CreateProduct = () => {
    const isLoggedIn=useSelector((state) => state?.auth?.isLoggedIn)
    const queryClient = useQueryClient();
    const [image, setImage] = useState(null);
    const {
      register,
      handleSubmit,
      watch,
      formState: { errors },
    } = useForm();
    const navigate = useNavigate();

    const { mutate } = useMutation({
      mutationFn: createItem,
      onSuccess: () => {
        console.log("Add successfully");
        //   queryClient.invalidateQueries({ queryKey: ['userList'] })
        queryClient.invalidateQueries(["items"]);
      },
    });
    const submitHandler = async (data) => {
      const fd = new FormData();
      fd.append("name", data?.name);
      fd.append("price", data?.price);
      fd.append("description", data?.description);
      fd.append("brand", data?.brand);

      fd.append("image", image);

      console.log(fd);

      mutate(fd);
      navigate("/dashboard");
    };

    return (
      
      <div>
        {/* <Nav/> */}
        {" "}
        <div>
          <div className="d-flex align-items-center justify-content-evenly ">
            
            <form className="m-5 p-5" onSubmit={handleSubmit(submitHandler)}>
            <h1>Create Product</h1>

              <div className="row mb-3">
                
                <div className="col-sm-10">
                  <input
                    type="text"
                    placeholder="Name"
                    className="form-control"
                    id="inputEmail3"
                    {...register("name", { required: true })}
                  />
                </div>
              </div>
              <div className="row mb-3">
                
                <div className="col-sm-10">
                  <input
                    type="number"
                    placeholder="Price"
                    className="form-control"
                    id="inputEmail4"
                    {...register("price", { required: true })}
                  />
                </div>
              </div>
              <div className="row mb-3">
                
                <div className="col-sm-10">
                  <input
                    type="text"
                    placeholder="Description"
                    className="form-control"
                    id="inputEmail5"
                    {...register("description", { required: true })}
                  />
                </div>
              </div>
              <div className="row mb-3">
               
                <div className="col-sm-10">
                  <input
                    type="text"
                    placeholder="Brand"
                    className="form-control"
                    id="inputEmail6"
                    {...register("brand", { required: true })}
                  />
                </div>
              </div>

              <div className="input-group mb-3">
                
                <input
                  type="file"
                  className="form-control"
                  id="inputGroupFile02"
                  onChange={(e) => setImage(e.target.files[0])}
                />
              </div>

              <div className="d-flex flex wrap gap-5">
                <button type="submit" className="btn btn-primary">
                  Create Product
                </button>
                
              </div>
              <div className="dashboard">
                <button
                  onClick={() => navigate("/dashboard")}
                  className="btn btn-dark"
                >
                  Go to dashBoard
                </button>
                </div>
            </form>
          </div>
        </div>
      </div>
    );
  };


export default CreateProduct;
