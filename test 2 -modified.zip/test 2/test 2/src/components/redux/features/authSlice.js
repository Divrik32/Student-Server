import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  user:localStorage.getItem("user")
  ? JSON.parse(localStorage.getItem("user"))
  : null,
  token:localStorage.getItem("token")
  ? JSON.parse(localStorage.getItem("token"))
  : null,
  isLoggedIn: localStorage.getItem("token")?(JSON.parse(localStorage.getItem("token"))):(null),
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logIn: (state, action) => {
      state.user = action.payload.user
      // console.log( action.payload);
    state.token = action.payload.token
    localStorage.setItem('token',JSON.stringify(action.payload.token))

    state.isLoggedIn = true;
    },
    logout:
      (state) => {
        localStorage.removeItem('user')
        localStorage.removeItem('token')
        state.user = null
        state.token = null
        if (state.token==null) {
          
          state.isLoggedIn = false;
        }
      
    }
}})


export const { logIn,logout } = authSlice.actions

export default authSlice.reducer