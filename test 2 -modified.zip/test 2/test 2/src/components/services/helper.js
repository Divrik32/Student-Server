import toast from "react-hot-toast";
import { axiosInstance } from "./axiosInstance";

export const login = async (data) => {
  try {
    const res = await axiosInstance.post("/login", data);
    console.log(res?.data);
    toast.success(res?.data?.message);
    localStorage.setItem("token", JSON.stringify(res?.data?.token));
    localStorage.setItem("user", JSON.stringify(res?.data?.user));
    return res?.data;
  } catch (error) {
    console.log(error);
    toast.error(error.message);
  }
};

export const signup = async (data) => {
  try {
    const res = await axiosInstance.post("/register", data);
    console.log(res?.data);
    toast.success(res?.data?.message);
  } catch (error) {
    console.log(error);
  }
};

export const getItem = async () => {
  // console.log(localStorage.getItem('token'));
  try {
    const response = await axiosInstance.get("/product", {
      headers: { "x-access-token": JSON.parse(localStorage.getItem("token")) },
    });

    toast.success(response?.data?.message);
    console.log(response?.data);
    return response?.data;
  } catch (error) {
    console.log(error);
  }
};

export const createItem = async (data) => {
  // console.log(localStorage.getItem('token'));
  try {
    const response = await axiosInstance.post("/create/product", data, {
      headers: { "x-access-token": JSON.parse(localStorage.getItem("token")) },
    });

    console.log(response?.data);
    toast.success(response?.data?.message);
    return response?.data;
  } catch (error) {
    console.log(error);
  }
};

export const deleteItem = async (data) => {
  // console.log(localStorage.getItem('token'));
  try {
    const response = await axiosInstance.delete(`/delete/product/${data}`, {
      headers: { "x-access-token": JSON.parse(localStorage.getItem("token")) },
    });

    //   console.log(response?.data);
    toast.success(response?.data?.message);
    return response.data;
  } catch (error) {
    console.log(error);
  }
};

export const updateItem = async (data) => {
  try {
    const response = await axiosInstance.post(
      `/update/product/${data.id}`,
      data?.fd,
      {
        headers: {
          "x-access-token": JSON.parse(localStorage.getItem("token")),
        },
      }
    );

    toast.success(response?.data?.message);
    //   console.log(response?.data);
    return response?.data;
  } catch (error) {
    console.log(error);
  }
};

export const getProductById = async (id) => {
  // console.log(localStorage.getItem('token'));
  try {
    const response = await axiosInstance.get(`/edit/product/${id}`, {
      headers: { "x-access-token": JSON.parse(localStorage.getItem("token")) },
    });

    //   console.log(response?.data);
    return response?.data;
  } catch (error) {
    console.log(error);
  }
};
