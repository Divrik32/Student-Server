import React from "react";
import toast from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { baseUrl } from "../services/axiosInstance";
import { logout } from "../redux/features/authSlice";

const Nav = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const user = useSelector((state) => state?.auth?.user);
  // const token = useSelector((state) => state?.auth?.token);
  const isLoggedIn =useSelector((state) => state?.auth?.isLoggedIn)
  //   console.log(user);
  // console.log(token);

    const logoutHandler = () => {
      dispatch(logout());
      toast.success("Logout");
      navigate("/login");
    };

  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid ">
          <a className="navbar-brand ">
            <div className="d-flex flex wrap gap-2 align-items-center ">
              <img
                src="src\components\image\server.jpg"
                alt=""
                height={70}
                width={70}
                className="rounded-circle"
              />
              <h3>Student server</h3>
            </div>
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0"></ul>
            <div>
              {isLoggedIn ? (
                <div className="d-flex flex wrap gap-3 align-items-center ">
                  <div className="d-flex flex wrap gap-1">
                    <button
                      className="btn btn-light"
                      onClick={() => navigate("/create")}
                    >
                      Create Product
                    </button>
                  </div>
                  <img
                    src={`${baseUrl}/${user.image}`}
                    alt=""
                    height={60}
                    width={60}
                    className="rounded-circle"
                  />
                  <div>
                    <h5>{user.name}</h5>
                  </div>
                  <div>
                    <button
                      className="btn btn-secondary"
                        onClick={logoutHandler}
                    >
                      Logout
                    </button>
                  </div>
                </div>
              ) : (
                <div className="d-flex flex wrap gap-1">
                  <button
                    className="btn btn-outline-dark"
                    onClick={() => navigate("/login")}
                  >
                    Login
                  </button>
                  <button
                    className="btn btn-putline-light"
                    onClick={() => navigate("/signup")}
                  >
                    Sign Up
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Nav;
